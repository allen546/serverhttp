import datetime
def gettime():
    return str(datetime.datetime.now())[11:19]

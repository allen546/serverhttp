version = 'python-httpserver/1.4.2'
